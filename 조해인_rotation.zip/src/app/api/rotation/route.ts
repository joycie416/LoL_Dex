import { NextResponse } from "next/server";
// import { getRotation } from "../server-action";

const API_KEY = process.env.RIOT_API_KEY;

// Get rotation data
const ROTATION_URL =
  "https://br1.api.riotgames.com/lol/platform/v3/champion-rotations";


export async function Get () {
  try {
    const res = await fetch(ROTATION_URL, {
      method: "GET",
      headers: {
        // "Content-Type": "application/json",
        // "User-Agent":
        //   "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Whale/3.28.266.11 Safari/537.36",
        // "Accept-Language": "ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7",
        // "Accept-Charset": "application/x-www-form-urlencoded; charset=UTF-8",
        // "Origin": "https://developer.riotgames.com",
        "X-RIOT-TOKEN" : API_KEY || '',
      },
    });
    const data = await res.json();
    console.log('get ro data:', data)
    return Object.entries(data);
  } catch (err) {
    console.error(err);
    return null;
  }

  // return NextResponse.json({data:res})
}