export type RType = {
  freeChampionIds: number[],
  freeChampionIdsForNewPlayers:  number[],
  maxNewPlayerLevel: number
}